// DEPRECATED: This file is no longer used
// The application now uses NextAuth for authentication
// See: src/hooks/useAuth.ts for the current authentication hook

export {};
